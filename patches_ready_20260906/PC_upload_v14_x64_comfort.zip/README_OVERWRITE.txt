PC 20260909 x64+comfort pack v14 stamp=20260909_010302
ROOT CAUSE (open fail): v11/v12 Mir3.exe were x86 (3929600) vs x64 d3dx9_43.dll -> BadImageFormatException.
This pack: x64 Mir3.exe/Mir3Game.exe (4130304 from v9/v13) + ClientSystem with boots Comfort ItemInfoStat correct.
Comfort (ItemInfoStat only; ItemInfo has NO Comfort column): cao1 pi2 wu3 chi4 tian5 elite7
WearWeight=wear-burden HandWeight=wrist; BagWeight/AC/MR cleared on boots.
USE THIS PACK ONLY for 7091 overwrite. NEVER use v11/v12 (x86 tip). NEVER Server.exe/Library.dll.
Mir3.exe size=4130304 md5=a346c5a32c23bdcaaa59f792c6a577da
Mir3Game.exe size=4130304 md5=a346c5a32c23bdcaaa59f792c6a577da
ClientSystem.db size=8421136 md5=9a6a678a93a4fa14df1f8886472160de
Flat: PList.Bin + Mir3.exe.gz + Mir3Game.exe.gz + Data-ClientSystem.db.gz
  PList.Bin                 117813
  Mir3.exe.gz               2161137
  Mir3Game.exe.gz           2161141
  Data-ClientSystem.db.gz   8423745
